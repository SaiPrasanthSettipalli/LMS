import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-penality',
  templateUrl: './penality.component.html',
  styleUrls: ['./penality.component.css']
})
export class PenalityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
